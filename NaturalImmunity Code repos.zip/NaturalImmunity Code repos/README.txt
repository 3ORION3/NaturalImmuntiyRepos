Unable to build and publish android app, apparently a file exceeded 50mb, 
which none did, I hope the video and code can display all aspects of this app. Thank you