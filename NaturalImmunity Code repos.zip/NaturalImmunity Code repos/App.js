import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import WelcomeScreen from './screens/WelcomeScreen';
import AboutScreen from './screens/AboutScreen';
import Footer from './Footer';

import { navigationRef } from '../NaturalImmunity/RootNavigation';
import ColdTherapyScreen from './screens/ColdTherapyScreen';
import YogaScreen from './screens/YogaScreen';
import MedicineScreen from './screens/MedicineScreen';
const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer ref={navigationRef}>
      <Stack.Navigator
        initialRouteName="WELCOME"
      >
        <Stack.Screen
          name="About This App"
          component={AboutScreen}
        />
        <Stack.Screen
          name="WELCOME"
          component={WelcomeScreen}
        />
        <Stack.Screen
          name="Medicine"
          component={MedicineScreen}
        />
        <Stack.Screen
          name="Yoga"
          component={YogaScreen}
        />
        <Stack.Screen
          name="Cold Therapy"
          component={ColdTherapyScreen}
        />
        
        
      </Stack.Navigator>
      <Footer></Footer>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#556b2f',
    alignItems: 'center',
    justifyContent: 'center',

  },
  text: {
    fontSize: 20,
    color: '#0000'

  },
});
