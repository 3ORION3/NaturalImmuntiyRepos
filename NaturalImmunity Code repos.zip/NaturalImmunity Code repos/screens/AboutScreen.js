import React from 'react';
import { Image, ImageBackground, StyleSheet, Text, View } from 'react-native';

function AboutScreen(props) {
    return (
        <ImageBackground
            style={styles.background}
            source={require("../assets/Nature 1.png")}
        >
            <View style={styles.logoContainer}>
                <Image
                    style={styles.logo}
                    source={require("../assets/logo.png")}
                />
                <Text style = {styles.text}>{"\n"}We believe nature is your friend, not your enemy{"\n\n"}
                You are powerful beyond measure{"\n\n"}And we welcome you to be a part of our journey{"\n\n"}
                Here we have compiled a collection of various ways{"\n\n"} to boost your natural immunity{"\n"} </Text>
            </View>

        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center'
    },
    logo: {
        width: 256,
        height: 256,
    },
    logoContainer: {
        position: 'absolute',
        top: 40,
        alignItems: 'center',
        bottom: 20
    },
    text: {
        fontSize: 18,
        color: 'white',
        textAlign: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
      },
})

export default AboutScreen;