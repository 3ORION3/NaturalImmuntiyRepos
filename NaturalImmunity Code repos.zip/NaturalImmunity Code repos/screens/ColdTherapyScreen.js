import React from 'react';
import { Image, ScrollView, ImageBackground, StyleSheet, Text, View } from 'react-native';

function ColdTherapyScreen(props) {
    return (
        <ImageBackground
            style={styles.background}
            source={require("../assets/Ice.png")}
        >
            <ScrollView style = {styles.scrollView}>
                <Text style = {styles.text}>
                    Cold therapy, exposing yourself to extremely cold temperatures {"\n\n"}
                    Can condition your body and boost your immunity tremendously{"\n\n"}
                    The Whim Hoff Method has shown evidence of completely eliminating disease{"\n\n"}

                    Breathing{"\n"}
The first pillar of the wim hof method is breathing. We’re always breathing, {"\n"}
yet we’re mostly unaware of its tremendous potential. {"\n"}
Heightened oxygen levels hold a treasure trove of benefits, {"\n"}
and the specialized breathing technique of the Wim Hof Method unearths them all: more energy, {"\n"}
reduced stress levels, and an augmented immune response that swiftly deals with pathogens.{"\n"}{"\n"}
{"\n"}<Image style = {styles.image}source={require("../assets/Cold Therapy/ColdTherapy1.png")}></Image>{"\n"}{"\n"}
Cold therapy{"\n"}
The cold is your warm friend and one of the three pillars of the wim hof method . {"\n"}
Proper exposure to the cold starts a cascade of health benefits, {"\n"}
including the buildup of brown adipose tissue and resultant fat loss, {"\n"}
reduced inflammation that facilitates a fortified immune system, balanced hormone levels, {"\n"}
improved sleep quality, and the production of endorphins— the feel - {"\n"}
good chemicals in the brain that naturally elevate your mood{"\n"}{"\n"}
{"\n"}<Image style = {styles.image}source={require("../assets/Cold Therapy/ColdTherapy2.png")}></Image>{"\n"}{"\n"}
Commitment{"\n"}
The third pillar of the wim hof method is the foundation of the other two: {"\n"}
both cold exposure and conscious breathing require patience and dedication in order to be fully mastered. {"\n"}
Armed with focus and determination you are ready to explore and eventually master your own body and mind.{"\n"}
{"\n"}<Image style = {styles.image}source={require("../assets/Cold Therapy/ColdTherapy3.png")}></Image>  {"\n"} {"\n"}  
                </Text>
            </ScrollView>    
            

        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center'
    },
    logo: {
        width: 256,
        height: 256,
    },
    logoContainer: {
        position: 'absolute',
        top: 70,
        alignItems: 'center'
    },
    text: {
        fontSize: 18,
        color: 'white',
        textAlign: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.75)',
    },
    image:{
        width: 150,
        height: 100,
    },
    scrollView: {
        alignContent: 'center',
    }
})

export default ColdTherapyScreen;