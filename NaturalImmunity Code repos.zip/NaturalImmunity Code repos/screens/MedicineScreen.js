import React from 'react';
import { Image, ScrollView, ImageBackground, StyleSheet, Text, View } from 'react-native';

function MedicineScreen(props) {
    return (
        <ImageBackground
            style={styles.background}
            source={require("../assets/Nature 2.png")}
        >
            <ScrollView style = {styles.scrollView}>
            <Text style = {styles.text}>{"\n"}Your body is your temple{"\n"} 
            eating healthily is number one to boosting your immune system.
            {"\n"} You should eat fresh, organic foods to feel great 24/7{"\n\n"}
            All vegetables and fruits are nutritious,{"\n"} but these picks have the highest levels of good-for-you nutrients {"\n"}
            that help ward off disease, {"\n"}
            enhance cognition, and keep your heart healthy.{"\n"}{"\n"}

Sweet Potato
{"\n"}
Along with squash and carrots, sweet potatoes are rich in beta-carotene,{"\n"} a potent antioxidant that protects vision. 
Beta-carotene may also help reduce the risk of breast{"\n"} and ovarian cancers in post-menopausal women.{"\n"}
<Image style = {styles.image}source={require("../assets/Medicine/Medicine1.png")}></Image>
{"\n"}{"\n"}
Sweet Red Peppers
{"\n"}
Surprisingly, sweet red peppers have twice the vitamin C of oranges. {"\n"}
This important vitamin is essential for maintaining healthy teeth and gums.{"\n"}
<Image style = {styles.image}source={require("../assets/Medicine/Medicine2.png")}></Image>
{"\n"}{"\n"}
Broccoli
{"\n"}
Rich in flavonoids, broccoli helps fight oxidative stress, which damages cells and leads to inflammation. {"\n"}
Broccoli may help ward off heart disease, type 2 diabetes, and cancer.{"\n"}
<Image style = {styles.image}source={require("../assets/Medicine/Medicine3.png")}></Image>
{"\n"}{"\n"}
Dark Leafy Greens
{"\n"}
People who eat more greens score better on tests measuring general cognition and memory{"\n"} (versus those that eat greens less often).{"\n"} 
Greens are brimming with iron, calcium, and vitamins A, C, and K.{"\n"}{"\n"}
<Image style = {styles.image}source={require("../assets/Medicine/Medicine4.png")}></Image>
{"\n"}{"\n"}
Tomatoes
{"\n"}
Tomatoes are nature's best source of lycopene, {"\n"}
a powerful antioxidant that may reduce cholesterol levels{"\n"} and protect against advanced-stage prostate cancer.{"\n"}
<Image style = {styles.image}source={require("../assets/Medicine/Medicine5.png")}></Image>

                 </Text>
            </ScrollView>

        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center'
    },
    logo: {
        width: 256,
        height: 256,
    },
    logoContainer: {
        position: 'absolute',
        top: 70,
        alignItems: 'center'
    },
    text: {
        fontSize: 18,
        color: 'white',
        textAlign: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.75)',
      },
    scrollView: {
        alignContent: 'center',
    },
    image:{
        width: 150,
        height: 100,
        resizeMode: 'cover',
    },
})

export default MedicineScreen;