import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { StyleSheet, ImageBackground, Text, View, Image } from 'react-native';

export default function WelcomeScreen() {
    return (<ImageBackground
        style={styles.background}
        source={require("../assets/Nature 3.png")}
    >
    
    </ImageBackground>

    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    logo: {
        flex: 1,
        width: null,
        height: null,
        resizeMode: 'contain'
    },
    logoContainer: {
        position: 'absolute',
        top: 70,
        alignItems: 'center'
    },
    background: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center'
    },
});