import React from 'react';
import { Image, ImageBackground, StyleSheet, Text, View, ScrollView } from 'react-native';

function YogaScreen(props) {
    return (
        <ImageBackground
            style={styles.background}
            source={require("../assets/Mandala1.png")}
        >
            <ScrollView style = {styles.scrollView}>
                <Text style = {styles.text}>
                Yoga can boost your immune system in many ways {"\n"}{"\n"}as it is not limited to just body movements and stretches.{"\n"}{"\n"}
                 Yoga is a way of life, a connection to the soul,{"\n"}{"\n"} it allows us to create flow to our entire energy field.{"\n"}{"\n"}
                  Breathwork during yoga is imperative{"\n"}{"\n"} as it aids in the flow, whilst being mindful.{"\n"}{"\n"}
                   Here are a list of yoga techniques that you can do everyday...{"\n"}{"\n"}

Child's Pose{"\n"}
This calming pose is a good default pause position.{"\n"} You can use child’s pose to rest and refocus before continuing to your next pose.
{"\n"} It gently stretches your lower back, hips, thighs,{"\n"} knees and ankles and relaxes your spine, shoulders and neck.

{"\n"}{"\n"}<Image style = {styles.image}source={require("../assets/Yoga Poses/YogaPose6.png")}></Image>
{"\n"}{"\n"} 
Downward-Facing Dog{"\n"}
Downward-facing dog strengthens the arms,{"\n"} shoulders and back while stretching the hamstrings, calves and arches of your feet.
{"\n"} It can also help relieve back pain.

{"\n"}{"\n"}<Image style = {styles.image}source={require("../assets/Yoga Poses/YogaPose5.png")}></Image>{"\n"}{"\n"}

Plank Pose{"\n"}
A commonly seen exercise, plank helps build strength in the core, shoulders, arms and legs.
{"\n"}{"\n"}<Image style = {styles.image}source={require("../assets/Yoga Poses/YogaPose3.png")}></Image>{"\n"}{"\n"}

Four-Limbed Staff Pose{"\n"}
This push-up variation follows plank pose in a common yoga sequence known as the sun salutation.{"\n"} 
It is a good pose to learn if you want to eventually work on more advanced poses,{"\n"} such as arm balances or inversions.
{"\n"}{"\n"}<Image style = {styles.image}source={require("../assets/Yoga Poses/YogaPose4.png")}></Image>{"\n"}{"\n"}

Cobra Pose{"\n"}
This back-bending pose can help strengthen the back muscles,
{"\n"} increase spinal flexibility and stretches the chest, shoulders and abdomen.
{"\n"}{"\n"}<Image style = {styles.image}source={require("../assets/Yoga Poses/YogaPose2.png")}></Image>{"\n"}{"\n"}

Tree Pose{"\n"}
Beyond helping improve your balance, it can also strengthen your core, ankles, calves, thighs and spine.
{"\n"}{"\n"}<Image style = {styles.image}source={require("../assets/Yoga Poses/YogaPose1.png")}></Image>{"\n"}{"\n"}
                   </Text>
            </ScrollView> 
            
               

        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center'
    },
    logo: {
        width: 256,
        height: 256,
    },
    logoContainer: {
        position: 'absolute',
        top: 70,
        alignItems: 'center'
    },
    text: {
        fontSize: 18,
        color: 'white',
        textAlign: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.75)',
    },
    image:{
        width: 150,
        height: 100,
    },
    scrollView: {
        alignContent: 'center',
    }
})

export default YogaScreen;